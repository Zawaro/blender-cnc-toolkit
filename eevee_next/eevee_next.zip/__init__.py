# pylint: disable=fixme, import-error
import bpy
from bpy.utils import register_class
from bpy.props import PointerProperty
from bpy.utils import unregister_class

from .crop_canvas import (
  VIEW3D_PT_crop_canvas_panel,
  RENDER_PT_crop_canvas_format,
  CropCanvasProperties,
  crop_canvas_monitor,
)

classes = (
  RENDER_PT_crop_canvas_format,
  VIEW3D_PT_crop_canvas_panel,
  CropCanvasProperties,
)


def crop_canvas_monitor_handler(scene):
  crop_canvas_monitor(scene)


def register():
  for cls in classes:
    register_class(cls)

  bpy.types.Scene.crop_canvas_tool = PointerProperty(type=CropCanvasProperties)

  if crop_canvas_monitor_handler not in bpy.app.handlers.depsgraph_update_post:
    bpy.app.handlers.depsgraph_update_post.append(crop_canvas_monitor_handler)


def unregister():
  for cls in reversed(classes):
    unregister_class(cls)

  del bpy.types.Scene.crop_canvas_tool

  if crop_canvas_monitor_handler in bpy.app.handlers.depsgraph_update_post:
    bpy.app.handlers.depsgraph_update_post.remove(crop_canvas_monitor_handler)


if __name__ == "__main__":
  register()
